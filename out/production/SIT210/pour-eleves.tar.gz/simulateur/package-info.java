/**
 * Le package principal.
 */
package simulateur;