/**
 * Tout ce qui permet de générer des vues graphiques pour le simulateur
 * @author prou
 */
package visualisations;